//javascript tp load images
function changeImage1()
{
    document.getElementById("bigPicture").src = "../Imagenes/product1.png";
}

function changeImage2()
{
    document.getElementById("bigPicture").src = "../Imagenes/product2.png";
}

function changeImage3()
{
    document.getElementById("bigPicture").src = "../Imagenes/product3.png";
}

function changeImage4()
{
    document.getElementById("bigPicture").src = "../Imagenes/product4.png";
}
